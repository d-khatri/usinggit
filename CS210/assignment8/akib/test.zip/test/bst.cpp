#include "bst.h"

using namespace std;

bst::bst()
{
    head=NULL;
}

bst::~bst()
{
    //dtor
}










node* bst::successor(node* c)
{

 if(c->getRight() != NULL)
                {
                        node* a =c->getRight();
                        while(a->getLeft() != NULL)
                        {
                                a = a->getLeft();
                        }

                        return a;
                }

                else if(c->getRight() == NULL)
                {
                        node* a = c;
                        while(a->getParent() != NULL)
                        {
                                if(a->getParent()->getLeft() == a)
                                {
                                        return a->getParent();
                                }
                                a = a->getParent();
                        }
                        return c;
                }
}














int bst::Height(node* p)
{

int l=0,r=0,q=0;

  if(head->getLeft()==NULL && head->getRight()==NULL)
    {
	return 0;
    }
    else
    {
        l=Height(head->getLeft());
        r=Height(head->getRight());

        if (l>r)
        {
	l=l+1;
        q=l;
        }
        else
        {
            r=r+1;
            q=r;
           }


}
return q;
}













bool bst::inorderTraversal(node* headNode){

//cout<<headNode->getKey()<<endl;

    if(headNode==NULL){
        return(true);
    }else{
        inorderTraversal(headNode->getLeft());
        if(headNode->getParent()!=NULL){
            cout<<"Key is "<<headNode->getKey()<<" Parent is "<<headNode->getParent()->getKey()<<endl;
        }else{
            cout<<"Key is "<<headNode->getKey()<<" Parent is NULL"<<endl;
        }

        inorderTraversal(headNode->getRight());

    }
    return(true);
}

bool bst::treeInsertNode(node* newNode){
    if(head==NULL){
        head=newNode;
        return(true);
    }else{
        return(insertNode(newNode, head));
    }

}

bool bst::insertNode(node* newNode, node* headNode){

    if(headNode->getKey()==newNode->getKey()){
        cout<<"Cannot insert duplicates for "<<newNode->getKey()<<endl;
        return(false);
    }else if(headNode->getKey()<newNode->getKey()){
        if(headNode->getRight()==NULL){
            headNode->setRight(newNode);
            newNode->setParent(headNode);
            return(true);
        }else{
            return(insertNode(newNode, headNode->getRight()));
        }
    }else if(headNode->getKey()>newNode->getKey()){
        if(headNode->getLeft()==NULL){
            headNode->setLeft(newNode);
            newNode->setParent(headNode);
            return(true);
        }else{
            return(insertNode(newNode, headNode->getLeft()));
        }
    }

}


node* bst::deleteNode(node* victimNode){

int flag=1;
node *c;
node *d;
c=victimNode;
//c=search(a,val);
//if(c==NULL)
//{
//flag=0;
//return a;
//}
//else
{
if(victimNode->getLeft()==NULL && victimNode->getRight()==NULL)
{
if(victimNode->getParent()!=NULL)
{
if(victimNode==victimNode->getParent()->getLeft())
victimNode->getParent()->setLeft(NULL);
else
victimNode->getParent()->setRight(NULL);
}
else
{
flag=0;
cout<<"NULL";
return NULL;
}
}
else
if(victimNode->getLeft()==NULL && victimNode->getRight()!=NULL)
{
if(victimNode->getParent()!=NULL)
{
if(victimNode==victimNode->getParent()->getRight())
{
victimNode->getParent()->setRight(victimNode->getRight());
victimNode->getRight()->setParent(victimNode->getParent());
}
else
{
victimNode->getParent()->setLeft(victimNode->getRight());
victimNode->getRight()->setParent(victimNode->getParent());
}
}
else
{
flag=0;
victimNode->getRight()->setParent(NULL);
head=victimNode->getRight();

return NULL;
//a=c->rchild;
//return a;
}
}

else
if(victimNode->getLeft()!=NULL && victimNode->getRight()==NULL)
{
if(victimNode->getParent()!=NULL)
{
if(victimNode==victimNode->getParent()->getRight())
{
victimNode->getParent()->setRight(victimNode->getLeft());
victimNode->getLeft()->setParent(victimNode->getParent());
}
else
{
victimNode->getParent()->setLeft(victimNode->getRight());
victimNode->getRight()->setParent(victimNode->getParent());
}
}
else
{
flag=0;
victimNode->getLeft()->setParent(NULL);
head=victimNode->getLeft();
//a=c->rchild;
//return a;

return NULL;
}
}

else if(victimNode->getRight()!=NULL && victimNode->getLeft()!=NULL)
{
if(victimNode->getParent()!=NULL)
{
if(victimNode==victimNode->getParent()->getRight())
{
d=successor(victimNode);
victimNode->getParent()->setRight(victimNode->getRight());
d->setLeft(victimNode->getLeft());
victimNode->getLeft()->setParent(d);
victimNode->getRight()->setParent(c->getParent());
}
else
{
d=successor(victimNode);
victimNode->getParent()->setLeft(victimNode->getRight());
d->setLeft(victimNode->getLeft());
victimNode->getLeft()->setParent(d);
victimNode->getRight()->setParent(victimNode->getParent());
}
}
else
{
flag=0;
d=successor(victimNode);
victimNode->getRight()->setParent(NULL);
d->setLeft(victimNode->getLeft());
victimNode->getLeft()->setParent(d);
head=d;

//a=c->rchild;
//return NULL
}
}

}
if(flag==1)
{
return NULL;

}

    //implement this function
    //for nodes with two childern always replace by successor
    return(NULL);
}


node* bst::searchKey(int keyValue, node* headNode){
    if(headNode==NULL){
        return(NULL);
    }

    if(headNode->getKey()==keyValue){
        return(headNode);
    }

    if(headNode->getKey()<keyValue){
        return(searchKey(keyValue, headNode->getRight()));
    }else{
        return(searchKey(keyValue, headNode->getLeft()));
    }


}


node* bst::treeSearchKey(int keyValue){
    return(searchKey(keyValue, head));
}


bool bst::treeInorderTraversal(){
    return(inorderTraversal(head));
}

int bst::treeHeight(){
return(Height(head));

    //implement this function to return height of the tree
    //empty tree has height 0
    //tree with single node has height 1
    //return(0);
}
