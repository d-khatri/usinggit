How to compile the code:
g++ main.cpp bst.cpp node.cpp

How to run the code:
./a.out

Implement following two functions in bst.cpp
1. deleteNode: deleting a node from tree
2. treeHeight: print height of the tree

Make changes only in the body of these two functions.
Do not change anything else.

During the evaluation, we will overwrite all your code files except for bst.cpp
